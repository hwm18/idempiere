package cn.aidee.training.acct;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.compiere.acct.Doc;
import org.compiere.acct.DocLine;
import org.compiere.acct.Fact;
import org.compiere.acct.FactLine;
import org.compiere.model.MAccount;
import org.compiere.model.MAcctSchema;
import org.compiere.model.X_C_Charge_Acct;
import org.compiere.model.X_C_Project_Acct;
import org.compiere.util.DB;
import org.compiere.util.Env;

import cn.aidee.training.model.MCBilling;
import cn.aidee.training.model.MCBillingLine;

public class Doc_BillingEntry extends Doc {
	
	MCBilling budget = null;

	/**
	 *  Constructor
	 * 	@param ass accounting schemata
	 * 	@param rs record
	 * 	@parem trxName trx
	 */
	public Doc_BillingEntry (MAcctSchema as, ResultSet rs, String trxName)
	{
		super(as, MCBilling.class, rs, null, trxName);
	}	//	Doc_Amortization

	@Override
	protected String loadDocumentDetails() {
		setC_Currency_ID(NO_CURRENCY);
		budget = (MCBilling)getPO();
//		setDateDoc(budget.getDateAcct());
//		setDateAcct(budget.getDateAcct());
		p_lines = loadLines(budget);
		log.fine("Lines=" + p_lines.length);
	
		return null;
	}

	@Override
	public BigDecimal getBalance() {
		BigDecimal retValue = Env.ZERO;
		return retValue;
	}

	@Override
	public ArrayList<Fact> createFacts(MAcctSchema as) {
		ArrayList<Fact> facts = new ArrayList<Fact>();
		
		//  create Fact Header
		Fact fact = new Fact (this, as, Fact.POST_Actual);

		setC_Currency_ID (as.getC_Currency_ID());
		
		MCBilling budget = (MCBilling) getPO();

		FactLine dr = null;
		FactLine cr = null;

		MCBillingLine[] lines = budget.getLines(false);
		for(MCBillingLine line : lines){
			DocLine dl = new DocLine(line, this);
			
			dr = fact.createLine(dl, getProjectAcct(as, budget.getC_Billing_ID()), as.getC_Currency_ID(), line.getPaidAmt());
			cr = fact.createLine(dl, getProjectWIP(as, budget.getC_Billing_ID()), as.getC_Currency_ID(), null, line.getPaidAmt());
		}
		facts.add(fact);
		return facts;
	}
	
	/*
	 * Load Project Budget Line
	 *	@param projectBudget
	 *  @return DocLine Array
	 */
	private DocLine[] loadLines (MCBilling projectBudget){
		ArrayList<DocLine> list = new ArrayList<DocLine>();
		//
		MCBillingLine[] lines = projectBudget.getLines(false);
		for (int i = 0; i < lines.length; i++)
		{
			MCBillingLine line = lines[i];
			DocLine docLine = new DocLine(line, this);
			docLine.setAmount(line.getPaidAmt());
			log.fine(docLine.toString());
			list.add(docLine);
		}
		//	Convert to Array
		DocLine[] dls = new DocLine[list.size()];
		list.toArray(dls);
		
		return dls;
	}
	
	/**
	 * get Charge Acct
	 * @param as
	 * @return
	 */
	private MAccount getChargeAcct(MAcctSchema as, int C_Charge_ID)
	{
	
		String acctName = X_C_Charge_Acct.COLUMNNAME_Ch_Expense_Acct;
		
		
		String sql = "SELECT "+acctName
					+ " FROM "+X_C_Charge_Acct.Table_Name
					+ " WHERE "+X_C_Charge_Acct.COLUMNNAME_AD_Client_ID +"=?"
					+ " AND "+X_C_Charge_Acct.COLUMNNAME_C_AcctSchema_ID +"=?"
					+ " AND "+X_C_Charge_Acct.COLUMNNAME_C_Charge_ID +"=?"
					
						;
		
		int acct_id = DB.getSQLValueEx(getTrxName(), sql, as.getAD_Client_ID(), as.get_ID(), C_Charge_ID);	
		return MAccount.get(getCtx(), acct_id);
	}
	
	/**
	 * get Project Acct
	 * @param as
	 * @return
	 */
	private MAccount getProjectAcct(MAcctSchema as, int C_Project_ID)
	{
	
		String acctName = X_C_Project_Acct.COLUMNNAME_PJ_Asset_Acct;
		
		String sql = "SELECT "+acctName
					+ " FROM "+X_C_Project_Acct.Table_Name
					+ " WHERE "+X_C_Project_Acct.COLUMNNAME_AD_Client_ID+"=?"
					+" AND "+X_C_Project_Acct.COLUMNNAME_C_AcctSchema_ID+"=?"
					+" AND "+X_C_Project_Acct.COLUMNNAME_C_Project_ID+"=?"
					
						;
		
		int acct_id = DB.getSQLValueEx(getTrxName(), sql, as.getAD_Client_ID(), as.get_ID(), C_Project_ID);	
		return MAccount.get(getCtx(), acct_id);
	}
	
	/**
	 * get Project Acct
	 * @param as
	 * @return
	 */
	private MAccount getProjectWIP(MAcctSchema as, int C_Project_ID)
	{
	
		String acctName = X_C_Project_Acct.COLUMNNAME_PJ_WIP_Acct;
		
		String sql = "SELECT "+acctName
					+ " FROM "+X_C_Project_Acct.Table_Name
					+ " WHERE "+X_C_Project_Acct.COLUMNNAME_AD_Client_ID+"=?"
					+" AND "+X_C_Project_Acct.COLUMNNAME_C_AcctSchema_ID+"=?"
					+" AND "+X_C_Project_Acct.COLUMNNAME_C_Project_ID+"=?"
					
						;
		
		int acct_id = DB.getSQLValueEx(getTrxName(), sql, as.getAD_Client_ID(), as.get_ID(), C_Project_ID);	
		return MAccount.get(getCtx(), acct_id);
	}

}

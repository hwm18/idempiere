package cn.aidee.training.validator;
import org.adempiere.base.IModelValidatorFactory;
import org.adempiere.base.equinox.EquinoxExtensionLocator;
import org.compiere.model.ModelValidator;

/**
 * @author Alex Yang
 *
 */
public class AIDEE_ValidatorFactory implements IModelValidatorFactory {

	@Override
	public ModelValidator newModelValidatorInstance(String className) {
		ModelValidator validator = EquinoxExtensionLocator.instance().locate(ModelValidator.class, "org.adempiere.base.ModelValidator", className, null).getExtension();
		if (validator == null) {
			Class<?> clazz = null;
			
			//use context classloader if available
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			if (classLoader != null) {
				try {
					clazz = classLoader.loadClass(className);
				}
				catch (ClassNotFoundException ex) {
				}
			}
			if (clazz == null) {
				classLoader = this.getClass().getClassLoader();
				try {
					clazz = classLoader.loadClass(className);
				}
				catch (ClassNotFoundException ex) {
				}
			}
			if (clazz != null) {
				try {
					validator = (ModelValidator)clazz.newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				} 
			} else {
				new Exception("Failed to load model validator class " + className).printStackTrace();
			}
		}
		
		return validator;
	}

}

/**
 * 
 */
package cn.aidee.training.process;

import java.util.logging.Level;

import org.compiere.process.ProcessInfoParameter;
import org.compiere.process.SvrProcess;
import org.compiere.util.AdempiereUserError;
import cn.aidee.training.model.MCBilling;

/**
 * @author Alex Yang
 *
 */
public class GenerateBillingLine extends SvrProcess
{

	/** The Record						*/
	private int		p_Record_ID = 0;
	
	/**
	 *  Prepare - e.g., get Parameters.
	 */
	protected void prepare()
	{
		ProcessInfoParameter[] para = getParameter();
		for (int i = 0; i < para.length; i++)
		{
			String name = para[i].getParameterName();
			if (para[i].getParameter() == null)
				;			
			else
				log.log(Level.SEVERE, "Unknown Parameter: " + name);
		}
		p_Record_ID = getRecord_ID();
	}	//	prepare

	/**
	 * 	Process
	 *	@return message
	 *	@throws Exception
	 */
	protected String doIt() throws Exception
	{
		int cnt = 0;
		
		MCBilling bil = new MCBilling(getCtx(), p_Record_ID, get_TrxName());
		if (bil.getC_Billing_ID() == 0)
			throw new AdempiereUserError("@No@ @Billing@");

		cnt = bil.recalcBillingLines();
		
		if (cnt == -1)
			throw new AdempiereUserError("Error calculating billing line, please check log");

		return "@Inserted@=" + cnt;		
	}	//	doIt

}

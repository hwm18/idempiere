/******************************************************************************
 * Product: Adempiere ERP & CRM Smart Business Solution                       *
 * Copyright (C) 2010 Heng Sin Low                							  *
 * This program is free software; you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program; if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 *****************************************************************************/
package cn.aidee.training.model;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Properties;

import org.compiere.util.DB;
import org.compiere.util.Env;

import cn.aidee.training.model.MCBilling;

/**
 * @author Alex Yang
 *
 */
public class MCBillingLine extends X_C_BillingLine
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MCBillingLine(Properties ctx, int C_BillingLine_ID,
			String trxName) {
		super(ctx, C_BillingLine_ID, trxName);
		// TODO Auto-generated constructor stub
	}

	public MCBillingLine(Properties ctx, ResultSet rs, String trxName) {
		super(ctx, rs, trxName);
		// TODO Auto-generated constructor stub
	}

	protected boolean afterDelete(boolean success) {
		updateHeaderAmount();
		return true;
	}

	protected boolean afterSave(boolean newRecord, boolean success) {
		updateHeaderAmount();
		return true;
	}

	@Override
	protected boolean beforeSave(boolean newRecord) {
		
		return true;
	}

	private boolean updateHeaderAmount(){
		
		MCBilling billHdr = getParent();
		
		// Find Total Bill Amount 
		String sql = "SELECT SUM(NetAmtToInvoice) FROM C_BillingLine WHERE C_Billing_ID = ? AND IsActive='Y' ";
		BigDecimal totalLineNetAmt = DB.getSQLValueBD(get_TrxName(), sql, billHdr.getC_Billing_ID());
		
		billHdr.setGrandTotal(totalLineNetAmt == null ? Env.ZERO : totalLineNetAmt);
		
		if(!billHdr.save(get_TrxName())){
			log.saveError("Cannot Update Billing Header", "Cannot Save Billing Header");
			return false;
		}

		return true;
	}
	
	private MCBilling parent = null ;
	
	public MCBilling getParent(){
		if(parent == null)
			parent = MCBilling.getBilling(getCtx(), getC_Billing_ID(), get_TrxName());
		
		return parent;
	}

}

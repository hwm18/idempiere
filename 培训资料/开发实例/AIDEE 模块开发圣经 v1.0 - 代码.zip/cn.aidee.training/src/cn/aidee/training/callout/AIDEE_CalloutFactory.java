package cn.aidee.training.callout;

import java.util.ArrayList;
import java.util.List;

import org.adempiere.base.IColumnCallout;
import org.adempiere.base.IColumnCalloutFactory;
import org.compiere.model.MProduct;

import cn.aidee.training.model.MCBilling;

public class AIDEE_CalloutFactory implements IColumnCalloutFactory {

	@Override
	public IColumnCallout[] getColumnCallouts(String tableName,
			String columnName) {
		
		List<IColumnCallout> list = new ArrayList<IColumnCallout>();
		
		if (tableName.equals(MCBilling.Table_Name) && columnName.equals(MCBilling.COLUMNNAME_C_BPartner_ID)) {
			list.add(new AIDEE_CalloutFromFactory());
		}
		return list != null ? list.toArray(new IColumnCallout[0]) : new IColumnCallout[0];
	}

}

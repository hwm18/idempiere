package cn.aidee.training.model;


import java.sql.ResultSet;

import org.adempiere.base.IModelFactory;
import org.compiere.model.I_C_Project;
import org.compiere.model.I_C_ProjectTask;
import org.compiere.model.I_C_ProjectType;
import org.compiere.model.PO;
import org.compiere.util.Env;

/**
 * @author Alex Yang
 *
 */
public class AIDEE_ModelFactory implements IModelFactory {

	@Override
	public Class<?> getClass(String tableName) {
		 if (tableName.equals(I_C_Billing.Table_Name)) {
		     return MCBilling.class;
		     
		   } else if (tableName.equals(I_C_BillingLine.Table_Name)) {
				 return MCBillingLine.class;				     
		   
		   } else 	   
			   return null;
	}

	@Override
	public PO getPO(String tableName, int Record_ID, String trxName) {
		if (tableName.equals(I_C_Billing.Table_Name)) {
		     return new MCBilling(Env.getCtx(), Record_ID, trxName);
		     
		 } else if (tableName.equals(I_C_BillingLine.Table_Name)) {
			 return new MCBillingLine(Env.getCtx(), Record_ID, trxName);		
		     
	   } else 	   
		   return null;
	}

	@Override
	public PO getPO(String tableName, ResultSet rs, String trxName) {
		if (tableName.equals(I_C_Billing.Table_Name)) {
		     return new MCBilling(Env.getCtx(), rs, trxName);
		     
		 } else if (tableName.equals(I_C_BillingLine.Table_Name)) {
			 return new MCBillingLine(Env.getCtx(), rs, trxName);
		
		 } else 
			   return null;
	}
}

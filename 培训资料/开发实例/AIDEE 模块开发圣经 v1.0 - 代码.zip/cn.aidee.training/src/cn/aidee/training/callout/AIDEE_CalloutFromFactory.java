package cn.aidee.training.callout;

import java.util.Properties;
import java.util.logging.Level;

import org.adempiere.base.IColumnCallout;
import org.compiere.model.GridField;
import org.compiere.model.GridTab;
import org.jfree.util.Log;

public class AIDEE_CalloutFromFactory extends CalloutBilling implements IColumnCallout {

	@Override
	public String start(Properties ctx, int WindowNo, GridTab mTab,
			GridField mField, Object value, Object oldValue) {
		
		if (mField.getColumnName().equals("C_BPartner_ID"))
			return bPartner(ctx, WindowNo, mTab, mField,value,oldValue);
		
		return null;
	}

}
